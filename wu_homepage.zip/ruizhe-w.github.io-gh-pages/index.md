---
layout: single
author_profile: true
---
<a name="home"></a>

### About

I am a second-year CS MMath student and an incoming Ph.D. student at the University of Waterloo, co-advised by Prof. [N. Asokan](https://asokan.org/asokan/) and Prof. [Meng Xu](https://cs.uwaterloo.ca/~m285xu/).

I got my B.S. degree from the University of Wisconsin-Madison, majoring in Computer Sciences (w/ honor) and
Mathematics. My advisor is Prof. [Earlence Fernandes](http://www.earlence.com), and I was a member of the [Madison Security and
Privacy (MadS&P)](https://madsp.cs.wisc.edu). I also worked closely with Prof. [Rahul Chatterjee](https://pages.cs.wisc.edu/~chatterjee/). Prior to that, I spent two years at Beijing Institute of Technology majoring in the Internet of Things Engineering.

I was a research intern at the Max Planck Institute for Software Systems (MPI-SWS) under the supervision of Dr. [Elissa Redmiles](https://elissaredmiles.com/) in summer 2022.

My research focuses on Cyber Physical Systems Security.


### Publications

[5] Ruizhe Wang, Meng Xu, N. Asokan.
SeMalloc: Semantics-Informed Memory Allocator. **Proceedings of the 2024 ACM Conference on Computer and Communications Security (CCS)**, 2024

[4] Ruizhe Wang, Meng Xu, N. Asokan.
S2malloc: Statistically Secure Allocator for Use-After-Free Protection And More. **Proceedings of the 2024 Conference on Detection of Intrusions and Malware & Vulnerability Assessment (DIMVA)**, 2024

[3] Angelica Goetzen\*, Ruizhe Wang\*, Elissa M. Redmiles, Savvas Zannettou, Oshrat Ayalon.
Likes and Fragments: Examining Perceptions of Time Spent on TikTok. **arxiv Preprint**, 2023

[2] Yunang Chen, Amrita Roy Chowdhury, Ruizhe Wang, Andrei Sabelfeld, Rahul Chatterjee, and Earlence Fernandes. Data Privacy
in Trigger-Action Systems. In **IEEE Symposium on Security and Privacy (S&P) (Oakland)**, 2021

[1] Yuzhe Ma, Jon Sharp, Ruizhe Wang, Earlence Fernandes, and Xiaojin Zhu. Sequential Attacks on Kalman Filter-Based Forward
Collision Warning Systems. In **The Thirty-Fifth AAAI Conference on Artificial Intelligence (AAAI)**, 2021

### Awards

[8] **Sep 2022** David R. Cheriton Graduate Scholarship (CA$20000)

[7] **Feb 2021** ACM ICPC NCNA Regional 4th position (4/90)

[6] **Dec 2020** CRA (Computing Research Association) Outstanding Undergraduate Researcher Awards Honorable Mention

[5] **May 2020** DeWitt Scholarship of Department of Computer Sciences, UW-Madison ($8000)

[4] **All Semesters** Dean’s List of College of L&S, UW-Madison

[3] **Oct 2018** First-Class Academic Excellence Scholarship of Beijing Institute of Technology (10%)

[2] **Apr 2018** 3rd Place of Freshman Programming Contest at Beijing Institute of Technology (3/369)

[1] **Apr 2017** 2nd Price in Lssec Techall Beijing Institute of Technology Programming Contest (~10%)

<!-- ### Misc

Reversi Game: [link](/static/pac-man)

Calculate your  -->

### CV

Here is the link to my [CV](/static/cv.pdf)
